NOVATECH FIREBASE SETUP — READ BEFORE DEPLOYING

The website is prepared, but it WILL NOT work until the following manual security steps are completed.

1. In Firebase project novatech-c7f70, open Authentication > Sign-in method. Enable Email/Password.
2. In Authentication > Users, create ONE approved staff user with a strong unique password. Do not share it with customers.
3. Copy the new user's UID from Authentication > Users.
4. In Firestore Database > Rules, paste the contents of firestore.rules, replacing REPLACE_WITH_APPROVED_STAFF_UID with the exact UID, then Publish rules.
5. Confirm you are in the Novatech Firebase project, NOT Business Tracker.
6. Test locally or on a separate preview: sign in, verify test-order-001 appears, add an order, sign in on another device, verify the new order appears. Also verify a signed-out visitor cannot read orders.
7. Only after testing, upload the updated index.html to Netlify when deployment is available again. Do not change the live site before testing.

IMPORTANT:
- Firebase config in the HTML is a public web app identifier, NOT a secret admin key. Firestore rules are the actual data protection.
- Existing Firestore document /Orders/test-order-001 will show once signed in and authorized.
- The Clear orders button permanently deletes every order in the Orders collection. Use with care.
- No migration of old browser-local orders is automatic. Export old orders to CSV from the old live site before replacing it.
- Orders are shared only with the single approved staff UID. To add staff later, adjust the authorization design safely; do not open the database to all authenticated users.
- The app requires internet access to Firebase.
- Netlify may be blocking deployments until your credit cycle renews; building this ZIP does not bypass that.
- This ZIP contains the full website and supporting files. No npm install is required.
